//
//  UIPasteboard+DTWebArchive.h
//  DTWebArchive
//
//  Created by Oliver Drobnik on 9/2/11.
//  Copyright (c) 2011 Cocoanetics. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DTWebArchive;

@interface UIPasteboard (DTWebArchive)

@property(nonatomic,copy) DTWebArchive *webArchive;

@end
