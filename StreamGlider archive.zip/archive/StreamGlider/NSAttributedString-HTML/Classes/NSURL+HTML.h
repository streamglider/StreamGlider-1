//
//  NSURL+HTML.h
//  PagingTextScroller
//
//  Created by Oliver Drobnik on 24.03.11.
//  Copyright 2011 Cocoanetics. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSURL (HTML)

- (NSURL *)derivedBaseURL;

@end
