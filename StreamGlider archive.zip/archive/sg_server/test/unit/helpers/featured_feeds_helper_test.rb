require 'test_helper'

class FeaturedFeedsHelperTest < ActionView::TestCase
end
