require 'test_helper'

class ShareTosHelperTest < ActionView::TestCase
end
