require 'test_helper'

class StreamFeedsHelperTest < ActionView::TestCase
end
