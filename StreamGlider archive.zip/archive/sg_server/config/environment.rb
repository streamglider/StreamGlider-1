# Load the rails application
require File.expand_path('../application', __FILE__)

HOST_NAME = '<TODO: add your host name here>'

# Initialize the rails application
SgServer::Application.initialize!
